<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct()	{
		parent:: __construct();
		$this->load->database();
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->library('email');
		$this->load->model('distributors/Transaction_Model','txn_model');
		$this->load->model('distributors/Products_Model','product_model');
		$this->load->dbforge();
	}
########## USER ACCOUNT, LOGIN, VERIFY AND LOGOUT ################
	public function index($oid) {
		$sess_data = $this->session->userdata();
		if(isset($sess_data['user_details'][0])) {
		    
		    $block_cid = $sess_data['user_details'][0]->ic_id;
		    $block_q = $this->db->query("SELECT * FROM i_contacts WHERE ic_id='$block_cid' AND ic_owner='$oid'");
		    $block_r = $block_q->result();
		    
		    if($block_r[0]->ic_new_flag == "2") {
		        $this->session->unset_userdata('account_status');
        		$this->session->unset_userdata('user_details');
        		$this->session->unset_userdata('status');
        		
        		$data = array('account_status' => "blocked");
        	    $this->session->set_userdata($data);
        				
        		redirect(base_url().$this->config->item('dealer_login_red'));
		    }
			$rid = $sess_data['user_details'][0]->iu_ref;
			$uid = $sess_data['user_details'][0]->iu_id;

            $oid = $sess_data['user_details'][0]->iu_owner;
            
            
            $query = $this->db->query("SELECT SUM(it_amount) AS amt FROM i_txns WHERE it_owner='$oid' AND it_type IN ('Sale', 'Delivery','Credit Note') AND it_c_id='$rid'");
            $sl_amt = $query->result()[0]->amt;
            $data['sale_amount'] = $query->result();
			
			$query = $this->db->query("SELECT (SUM(itp_credit) - SUM(itp_debit)) AS amt FROM i_txn_payments WHERE itp_owner='$oid' AND itp_c_id='$rid'");
			$pd_amt = $query->result()[0]->amt;
            $data['paid_amt'] = $query->result();
			
			$data['outstanding'] = $sl_amt - $pd_amt;
// 			print_r($data);
			$data['pending'] = $this->txn_model->load_transactions_dealer($oid, 'done', $rid);
			
			$query = $this->db->query("SELECT * FROM `i_products` AS a LEFT JOIN i_category AS b ON a.ip_category=b.ica_id WHERE ip_category IS NOT NULL GROUP BY ip_category ORDER BY ip_created DESC LIMIT 10");
			$data['new_arrival'] = $query->result();
			
			$data['oid'] = $oid;

			$ert['name'] = $sess_data['user_details'][0]->ic_name;
			
			$ert['title'] = "Home";
			$ert['search'] = "false";
			$ert['search_placeholder'] = "Search Products";
			$ert['type'] = "dealers";
		
			$this->load->view('dealers/navbar', $ert);
			$this->load->view('dealers/home/home', $data);
		} else {
			redirect(base_url().$this->config->item('dealer_login_red'));
		}
	}
}
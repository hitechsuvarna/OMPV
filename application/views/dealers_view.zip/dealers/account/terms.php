<div style="margin:20px;">
<h3>About OMPV Application</h3>
<div style="font-size:1em;font-weight:bold;">TERMS & CONDITIONS</div>
<div style="font-size:0.8em; line-height:1em; text-align:justify;">
    <ol>
       <li>Received goods in order and good condition.</li> 
       <li>Goods supplied on order will not be accepted back.</li>
       <li>Delivery of the order will be done within 7 days of the order placing date.</li>
       <li>We declare the actual goods are as described and that the all particulars are correct to the best of our knowledge and belief.</li>
       <li>Our responsibility ceases absolutely as soon as goods are handed over to the carrier.</li>
       <li>Payment terms - Immediate. Interest @ 18% per annum will be charged on delayed payments.</li>
       
       <li>Warranty/Service of purchased goods is the manufacturers/ Importers responsibility under the warranty period.</li>
       <li>Subject to mumbai Jurisdiction.</li>
       <li>O M Prime Ventures shall not be responsible for any expenses involving legal costs in case of a dispute.</li>
       <li>I the user have accepted the terms and conditions of the application as mentioned above.</li>
    </ol>
</div>
<div style="padding:10px;">E.&.O.E.</div>
</div>
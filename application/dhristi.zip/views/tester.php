<style>
    body {
        background-image:url('https://timedotcom.files.wordpress.com/2016/08/blue-whales.jpg');
        background-size: cover;
        background-position:center;
        background-attachment:fixed;
    }
</style>
<body>
    
</body>
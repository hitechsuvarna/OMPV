<style>
	
    a {
        color: #fff;
        text-decoration: none;
    }

    a:hover {
        color: #fff;
        text-decoration: none;
    }

    table > tr > td > a {
        color: #ff0000 !important;
        text-decoration: none;
    }

    a:hover {
        color: #fff;
        text-decoration: none;
    }

    /*html, body {
        height: 100%;
        width: 100%;
        margin: 0;
        padding: 0;
        overflow: hidden;
    }*/
    
    .product_qty {
        border: 1px solid #999;
        border-radius: 3px;
        padding: 10px;
        text-align: center;
        margin-bottom: 10px;
        width: 70px;
    }

    .pending_orders_row {
        padding: 20px;
    }
</style>
<main class="mdl-layout__content">
    <div class="mdl-grid">
        <div class="mdl-cell mdl-cell--12-col">
            <h3>Welcome to OMPV Mobile Application.</h3>
        </div>
    </div>
    <div class="mdl-grid" id="transactions">
        <div class="mdl-cell mdl-cell--4-col" id="outstanding">
            <div class="mdl-card mdl-shadow--4dp">
                <!-- <div class="mdl-card__title mdl-card--expand"> -->
                    <h4>
                        Total Sale Outstanding:<br>
                        <h2>Rs.<?php print_r($sale_amount[0]->amt); ?>/-</h2><br>
                    </h4>
                <!-- </div> -->
            </div>
        </div>
        <div class="mdl-cell mdl-cell--4-col" id="outstanding_del">
            <div class="mdl-card mdl-shadow--4dp">
                <!-- <div class="mdl-card__title mdl-card--expand"> -->
                    <h4>
                        Total Sale Outstanding:<br>
                        <h2>Rs.<?php print_r($delivery_amount[0]->amt); ?>/-</h2><br>
                    </h4>
                <!-- </div> -->
            </div>
        </div>
        <div class="mdl-cell mdl-cell--4-col" id="pending_orders">
            <div class="mdl-card mdl-shadow--4dp">
                <div class="mdl-card__title">
                    <h2 class="mdl-card__title-text">
                        Pending Orders
                    </h2>
                </div>
                <div class="mdl-card__supporting-text">
                    <table style="width: 100%;" class="mdl-data-table mdl-js-data-table">
                        <?php 
                            for ($i=0; $i < count($pending) ; $i++) { 
                                echo '<tr><td><a href="'.base_url().$type.'/Transactions/order_details/'.$pending[$i]->it_id.'" style="color: #ff0000;">#'.$pending[$i]->it_txn_no.'</a></td><td>'.$pending[$i]->it_date.'</td><td>Rs.'.$pending[$i]->it_amount.'/-</td> </tr>';
                            }
                        ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="mdl-grid">
        <div class="mdl-cell mdl-cell--4-col">
            <div class="mdl-card mdl-shadow--8dp browse_more">
                <div class="mdl-card__title mdl-card--expand" style="background:  linear-gradient(rgba(20,20,20,.5), rgba(20,20,20, .5)), url('<?php echo base_url().'assets/photo/C1IMG1.jpg' ?>'); background-size:cover;">
                    <h2 class="mdl-card__title-text">Click to Browse Products</h2>
                </div>
            </div>
        </div>
    </div>
	
	<div class="mdl-grid" id="nothing">
	    <h1>Please contact Admin for pricing and products</h1>
	</div>
    <div id="demo-snackbar-example" class="mdl-js-snackbar mdl-snackbar">
        <div class="mdl-snackbar__text"></div>
        <button class="mdl-snackbar__action" type="button"></button>
    </div>
</main>
</div>

</body>
<script type="text/javascript">
    var products_arr = [], qty_arr = [], noth = false;
    $(document).ready( function() {
        <?php 
        
            $sess_data = $this->session->userdata();
            echo "$('.price').css('display','".$sess_data["price_display"]."');";
            if (count($sale_amount[0]->amt) > 0) { echo "$('#outstanding').css('display','block'); noth=false;"; } else {  echo "$('#outstanding').css('display','none'); noth=true;"; }
            if (count($delivery_amount[0]->amt) > 0) { echo "$('#outstanding_del').css('display','block'); noth=false;"; } else {  echo "$('#outstanding_del').css('display','none'); noth=true;"; }
            if (count($pending) > 0) { echo "$('#pending_orders').css('display','block');  noth=false;"; } else {  echo "$('#pending_orders').css('display','none'); noth=true;"; } 
            // if (count($product_list) > 0) { echo "$('#new_arrival').css('display','block'); noth=false;"; } else {  echo "$('#new_arrival').css('display','none'); noth=true;"; } 
       
       ?>
       
       $('#outstanding').click(function(e) {
            e.preventDefault();
            
            window.location = "<?php echo base_url().$type.'/Transactions/orders'; ?>"
       });
       
    //   if(noth==true) {
    //       $('#nothing').css('display','block');
    //   } else {
          $('#nothing').css('display','none');
    //   }
       
        $('#products').on('click','.qty_add', function(e) {
            e.preventDefault();
            var a = "#txt" + $(this).prop('id');
            var f=false, d=0;
            for (var i = 0; i < products_arr.length; i++) {
                if ($(this).prop('id') == products_arr[i]) {
                    f=true;
                    d=i;
                    break;
                }
            }
            var snackbarContainer = document.querySelector('#demo-snackbar-example');
            if(f==false) { add_to_list($(this).prop('id') , $(a).val()); } else { edit_list(d, $(this).prop('id'), $(a).val()); }

            $.post('<?php echo base_url().$type."/Products/update_cart"; ?>', { 'p' : products_arr, 'q' : qty_arr }, function(d,s,x) { var ert = {message: 'Cart Updated.',timeout: 2000, }; snackbarContainer.MaterialSnackbar.showSnackbar(ert); }, "text");

             
            
        });
        
        $('.browse_more').click(function(e) {
            e.preventDefault();
            
            window.location = "<?php echo base_url().$type.'/Products'; ?>";
        });

        function add_to_list(pid, qty) {
            products_arr.push(pid);
            qty_arr.push(qty);
        }

        function edit_list(id, pid, qty) {
            products_arr[id] = pid;
            qty_arr[id] = qty;
        }
    });
</script>
</html>
<pre style="font-family: Calibri;">
COMPANY PROFILE

We take immense pleasure to introduce ourselves as a premium car accessories distributors.

Car owners today are extremely conscious and passionate about maintaining their vehicles at its best. Thus, automotive accessories play a major role to enhance the decor.

This investment not only adds to the look and feel but also increases the trade-in value of the car.

Founded by Mr. Prakash Chandwani, O M Prime Ventures (O M P V) is the leading distributor in providing high quality and durable innovative products like car magnetic sun-shades, acrylic backlit footsteps, floor PVC lamination designed and conceptualized by itself.

O M P V are also leading distributors of brands like Bass effects, Kicker, Soundstream, Scosche, etc. 

Team O M P V has the required industry 
expertise and commitment to unsurpassed customer service since inception and we strive 
to make the process from order to delivery and dispatch easy and as convenient as possible by taking 
extra steps to be sure that we provide to our customers a timely delivery.

Our Vision

To service a wide range of meaningful, high quality and value for money automotive accessories in the market.

Our Mission

To innovate marketing solutions for meaningful auto accessory products

Trade with us
Prakash Chandwani - Contact No : +91 9867811759.

Email us on omprimeventures@gmail.com

Address
B/5, PINKY APARTMENT, NR. ICICI BANK LTD, RAM NAGAR, BORIVALI (WEST), MUMBAI-400092.
</pre>
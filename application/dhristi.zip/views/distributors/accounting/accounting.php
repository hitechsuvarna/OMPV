<style type="text/css">
	a {
        color: #fff;
        text-decoration: none;
    }

    a:hover {
        color: #fff;
        text-decoration: none;
    }

    /*html, body {
        height: 100%;
        width: 100%;
        margin: 0;
        padding: 0;
        overflow: hidden;
    }*/
    
    #products {
        width: 100%;
        text-align: left;
        border: 0px solid #ccc;
        border-collapse: collapse;
    }

    #products > thead > tr {
        box-shadow: 0px 5px 5px #ccc;
    }

    #products > thead > tr > th {
        padding: 10px;
    }

    #products > tbody > tr > td {
        padding: 15px;
    }

    #products > tbody > tr {
        border-bottom: 1px solid #ccc;
    }

    #products > tbody > tr > td {
        color: #666;
        text-decoration: none;
    }

</style>

<main class="mdl-layout__content">
    <div class="mdl-grid">
	    <div class="mdl-cell mdl-cell--12-col">
	    <h4>Masters</h4>
	    <hr>    
	    </div>
	    <div class="mdl-cell mdl-cell--col-3" id="journal_entry">
	        <div class="mdl-card mdl-shadow--4dp">
	            <div class="mdl-card__title mdl-card--expand">
	                <div class="mdl-card__title-text">
	                    Journal Entries    
	                </div>
	            </div>
	        </div>
	    </div>
	    <div class="mdl-cell mdl-cell--col-3" id="ledgers">
	        <div class="mdl-card mdl-shadow--4dp">
	            <div class="mdl-card__title mdl-card--expand">
	                <div class="mdl-card__title-text">
	                    Ledgers
	                </div>
	            </div>
	        </div>
	    </div>
	    <div class="mdl-cell mdl-cell--col-3" id="groups">
	        <div class="mdl-card mdl-shadow--4dp">
	            <div class="mdl-card__title mdl-card--expand">
	                <div class="mdl-card__title-text">
	                    Groups
	                </div>
	            </div>
	        </div>
	    </div>
	    <div class="mdl-cell mdl-cell--col-3" id="classes">
	        <div class="mdl-card mdl-shadow--4dp">
	            <div class="mdl-card__title mdl-card--expand">
	                <div class="mdl-card__title-text">
	                    Classes
	                </div>
	            </div>
	        </div>
	    </div>
    </div>
    <div class="mdl-grid">
	    <div class="mdl-cell mdl-cell--12-col">
	    <h4>Transactions</h4>
	    <hr>    
	    </div>
	    <div class="mdl-cell mdl-cell--col-3" id="trial_balance">
	        <div class="mdl-card mdl-shadow--4dp">
	            <div class="mdl-card__title mdl-card--expand">
	                <div class="mdl-card__title-text">
	                    Trial Balance
	                </div>
	            </div>
	        </div>
	    </div>
	</div>
	<div class="mdl-grid" id="starred">
	    <div class="mdl-cell mdl-cell--12-col">
	    <h4>Starred Ledgers</h4>
	    <hr>    
	    </div>
	    
	
	    <?php for($i=0;$i<count($ledgers);$i++) {
	        echo '<div class="mdl-cell mdl-cell--col-3 ledger_specific" id="'.$ledgers[$i]->inal_id.'">
	        <div class="mdl-card mdl-shadow--4dp">
	            <div class="mdl-card__title mdl-card--expand">
	                <div class="mdl-card__title-text">
	                    '.$ledgers[$i]->inal_ledger.'
	                </div>
	            </div>
	        </div>
	    </div>';
	    } ?>
	</div>
</div>
</div>
</body>
<script>
	$(document).ready(function() {
	    $('#journal_entry').click(function(e) {
	        e.preventDefault();
	        window.location = "<?php echo base_url().$type.'/Accounting/journal_entries'; ?>";
	    })
	    
	    $('#ledgers').click(function(e) {
	        e.preventDefault();
	        window.location = "<?php echo base_url().$type.'/Accounting/ledgers'; ?>";
	    });
	    
	    $('.ledger_specific').click(function(e) {
	        e.preventDefault();
	        window.location = "<?php echo base_url().$type.'/Accounting/ledger_details/'; ?>" + $(this).prop('id');
	    });
	    
	    $('#groups').click(function(e) {
	        e.preventDefault();
	        window.location = "<?php echo base_url().$type.'/Accounting/groups'; ?>";
	    });
	    
	    $('#classes').click(function(e) {
	        e.preventDefault();
	        window.location = "<?php echo base_url().$type.'/Accounting/classes'; ?>";
	    });
	    
	    $('#trial_balance').click(function(e) {
	        e.preventDefault();
	        window.location = "<?php echo base_url().$type.'/Accounting/trial_balance'; ?>";
	    });
	    
	    
	});
</script>
</html>
<style type="text/css">
	.purchase_table {
		width: 100%;
        text-align: left;
        border: 0px solid #ccc;
        border-collapse: collapse;
        
	}

	@media only screen and (max-width: 760px) {
		.purchase_table {
			display: block;
        	overflow: auto;
		}
	}

	.purchase_table > thead > tr {
		box-shadow: 0px 5px 5px #ccc;
	}

	.purchase_table > thead > tr > th {
		padding: 10px;
	}

	.purchase_table > tbody > tr {
		border-bottom: 1px solid #ccc;
	}

	.purchase_table > tbody > tr > td {
		padding: 15px;
	}

	.cart_table_details {
		width: 100%;
	}
	.amount {
		text-align: right;
	}

	#order_number {
		color: #ff0000;
	}

	#total_amount {
		color: #ff0000;
	}

	.product_qty {
        border: 1px solid #999;
        border-radius: 3px;
        padding: 10px;
        text-align: center;
        margin-bottom: 10px;
        width: 70px;
    }
    
    #print_data {
        display : none;
    }
    
    .detail_center {
        text-align:center;
    }
    
    .detail_right {
        text-align:right;
    }

    ::placeholder {
    	color: #999 !important;
	}
</style>


<main class="mdl-layout__content" style="display: non;">
	<div class="mdl-grid">
		<div class="mdl-cell mdl-cell--4-col">
			<div class="mdl-card mdl-shadow--4dp">
				<div class="mdl-card__title">
					<h2 class="mdl-card__title-text">Ledger Details</h2>
				</div>
				<div class="mdl-card__supporting-text" style="width: auto;">
				    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
						<input type="text" id="vendors" class="mdl-textfield__input" value="<?php if(isset($detail)) echo $detail[0]->inal_ledger; ?>">
						<label class="mdl-textfield__label" for="vendors">Ledger Name</label>
					</div>
					<div class="mdl-grid prop">
						<?php if (isset($detail_prop)) {
							for ($i=0; $i < count($detail_prop); $i++) { 
								echo '<div class="mdl-cell mdl-cell--12-col"><input type="text" id="p'.$i.'" class="mdl-textfield__input prop_title" value="'.$detail_prop[$i]->inald_property.'" placeholder="Property"><input type="text" id="v'.$i.'" class="mdl-textfield__input prop_value" value="'.$detail_prop[$i]->inald_value.'" placeholder="Value"></div>';
							}
						} ?>
					</div>
					<button class="mdl-button mdl-js-button mdl-button--colored" id="add_prop"><i class="material-icons">add</i> Add Properties</button>
					<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
						<label>Add Groups to this Ledger</label>
		            	<ul id="mygroups">
		            		<?php if(isset($detail_groups)) for ($i=0; $i < count($detail_groups); $i++) { 
		            			echo "<li>".$detail_groups[$i]->inag_group."</li>";
		            		}?>
		            	</ul>
					</div>
					<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
						<label>Add Classes to this Ledger</label>
		            	<ul id="myclasses">
		            		<?php if(isset($detail_classes)) for ($i=0; $i < count($detail_classes); $i++) { 
		            			echo "<li>".$detail_classes[$i]->inacc_name."</li>";
		            		}?>
		            	</ul>
					</div>
					<?php if (isset($detail)) echo '<button class="mdl-button mdl-js-button mdl-button--colored" id="del"><i class="material-icons">delete</i> DELETE</button>'; ?>
				</div>

			</div>
		</div>
	</div>
	<button class="lower-button mdl-button mdl-button-done mdl-js-button mdl-button--fab mdl-js-ripple-effect mdl-button--accent" id="submit">
		<i class="material-icons">done</i>
	</button>
</div>
</div>

</body>
<script>
	var tag_data = [], tag2_data =[], prop_data = [], cnt=0;
	$(document).ready(function() {
		<?php if (isset($detail_prop)) { echo "cnt=".count($detail_prop);} ?>

		<?php for ($i=0; $i < count($prop) ; $i++) { 
    			echo "prop_data.push('".$prop[$i]->inald_property."');";
    	} ?>
    	

    	$('#del').click(function(e) {
    		e.preventDefault();

    		window.location = "<?php if (isset($detail)) echo base_url().$type.'/Accounting/delete_ledger/'.$lid; ?>";
    	});
        <?php for($i=0;$i<count($groups);$i++) { echo 'tag_data.push("'.$groups[$i]->inag_group.'");'; } ?>
        $("#mygroups").tagit({
            autocomplete : { delay: 0, minLenght: 5},
            allowSpaces : true,
            availableTags : tag_data,
            allowDuplicates: true,
        });

        <?php for($i=0;$i<count($classes);$i++) { echo 'tag2_data.push("'.$classes[$i]->inacc_name.'");'; } ?>
        $("#myclasses").tagit({
            autocomplete : { delay: 0, minLenght: 5},
            allowSpaces : true,
            availableTags : tag2_data,
            allowDuplicates: true,
        });

        $('#add_prop').click(function(e) {
        	e.preventDefault();
        	cnt++;
        	$('.prop').append('<div class="mdl-cell mdl-cell--12-col"><input type="text" id="p' + cnt + '" class="mdl-textfield__input prop_title" placeholder="Property"><input type="text" id="v' + cnt + '" class="mdl-textfield__input prop_value" placeholder="Value"></div>');
        	$('#p'+cnt).autocomplete({
	            source: prop_data
	        }).focus();

        });
    	
    	$('#submit').click(function(e) {
			e.preventDefault();
			$(this).attr('disabled','disabled');
			groups_info = [];
		    $('#mygroups > li').each(function(index) {
				var tmpstr = $(this).text();
				var len = tmpstr.length - 1;
				if(len > 0) {
					tmpstr = tmpstr.substring(0, len);
					groups_info.push(tmpstr);
				}
			});

			classes_info = [];
		    $('#myclasses > li').each(function(index) {
				var tmpstr = $(this).text();
				var len = tmpstr.length - 1;
				if(len > 0) {
					tmpstr = tmpstr.substring(0, len);
					classes_info.push(tmpstr);
				}
			});

			prop_t_arr = [];
		    $('.prop_title').each(function(index) {
				prop_t_arr.push($(this).val());
			});

			prop_v_arr = [];
		    $('.prop_value').each(function(index) {
				prop_v_arr.push($(this).val());
			});



			$.post('<?php if(isset($detail)) { echo base_url().$type."/Accounting/save_ledger/".$lid; } else { echo base_url().$type."/Accounting/save_ledger/"; } ?>', {
			    'name': $('#vendors').val(),
			    'groups' : groups_info,
			    'classes' : classes_info,
			    'p_t' : prop_t_arr,
			    'p_v' : prop_v_arr
			 }, function(d,s,x) {
			 	window.location = "<?php echo base_url().$type.'/Accounting/ledgers'; ?>";
			 }, "text");
	    }); 
	});
</script>
</html>
<style>
	
    a {
        color: #fff;
        text-decoration: none;
    }

    a:hover {
        color: #fff;
        text-decoration: none;
    }

    /*html, body {
        height: 100%;
        width: 100%;
        margin: 0;
        padding: 0;
        overflow: hidden;
    }*/
    
    #products {
        width: 100%;
        text-align: left;
        border: 0px solid #ccc;
        border-collapse: collapse;
    }

    #products > thead > tr {
        box-shadow: 0px 5px 5px #ccc;
    }

    #products > thead > tr > th {
        padding: 10px;
    }

    #products > tbody > tr > td {
        padding: 15px;
    }

    #products > tbody > tr {
        border-bottom: 1px solid #ccc;
    }

    #products > tbody > tr > td {
        color: #666;
        text-decoration: none;
    }
</style>
<main class="mdl-layout__content">
    <div class="mdl-grid">
        <?php $b=""; for($i=0;$i<count($category); $i++) {
	        $b.='<div class="mdl-cell mdl-cell--2-col open" id="'.$category[$i]->ica_id.'"><div class="mdl-card mdl-shadow--2dp"><div class="mdl-card__title mdl-card--expand" style="background:linear-gradient(rgba(20,20,20,.3), rgba(20,20,20, .3)), url(\''.base_url().'assets/uploads/'.$oid.'/c/'.$category[$i]->ica_id.'/'.$category[$i]->ica_img.'\'); background-size:cover; "><div class="mdl-card__title-text">'.$category[$i]->ica_category_name.'</div></div></div></div>';
	        } echo $b;
	    ?>
    </div>
    <!--<div class="mdl-grid">
        <div class="mdl-cell mdl-cell--12-col">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
				<select id="p_category" class="mdl-textfield__input">
				    <option value="0">All</option>
				    <?php 
				        for($i=0;$i<count($category); $i++) {
				            //echo '<option value="'.$category[$i]->ica_id.'">'.$category[$i]->ica_category_name.'</option>';
				        }
				    ?>
				</select>
				<label class="mdl-textfield__label" for="p_name">Select Category</label>
			</div>
        </div>
    </div>-->
	<div class="mdl-grid">
        <table id="products">
            <tbody>
                <?php for ($i=0; $i < count($products) ; $i++) { 
                    echo '<tr id="'.$products[$i]->ip_id.'"> <td>'.$products[$i]->ip_name.'</td> </tr>';
                    }
                ?>
            </tbody>
        </table>
	</div>
    <div class="mdl-grid">
        <div class="mdl-cell mdl-cell--12-col">
            <button class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--colored" id="manage_category" style="width: 100%;">
                <i class="material-icons">group_work</i> Manage Categories
            </button>
                    
        </div>
    </div>
    <button class="lower-button mdl-button mdl-button-done mdl-js-button mdl-button--fab mdl-js-ripple-effect mdl-button--accent" id="submit">
        <i class="material-icons">add</i>
    </button>
</main>
</div>

</body>
<script type="text/javascript">
    $(document).ready(function() {
        $('div').on('click','.open', function(e) {
            e.preventDefault();
            window.location = "<?php echo base_url().$type.'/Products/load_category/'; ?>" + $(this).prop('id');
        });

        $('#manage_category').click(function(e) {
            e.preventDefault();
            window.location = "<?php echo base_url().$type.'/Products/manage_categories' ?>"
        })

        $('#fixed-header-drawer-exp').keyup(function(e) {
            $.post('<?php echo base_url().$type."/Products/search_products"; ?>', {
                'keywords' : $(this).val()
            }, function(data, status, xhr) {
                var a = JSON.parse(data), s = ""; $('#products').empty();
                for (var i = 0; i < a.length; i++) {
                    s+="<tr id='" + a[i].ip_id + "'><td>" + a[i].ip_name + "</td></tr>";
                }
                $('#products').append(s);
            }, "text");
        });

        $('#p_category').change(function(e) {
            $.post('<?php echo base_url().$type."/Products/filter_products"; ?>', {
                'search' : $(this).val()
            }, function(data, status, xhr) {
                var a = JSON.parse(data), s = ""; $('#products').empty();
                for (var i = 0; i < a.length; i++) {
                    s+="<tr id='" + a[i].ip_id + "'><td>" + a[i].ip_name + "</td></tr>";
                }
                $('#products').append(s);
            }, "text");
        });

        $('#products').on('click','tr', function(e) {e.preventDefault(); window.location = "<?php echo base_url().$type.'/Products/edit_product/'; ?>" + $(this).prop('id'); });
        
        
        $('#submit').click(function(e) {e.preventDefault(); window.location = "<?php echo base_url().$type.'/Products/add_product'; ?>"; });
    });
</script>
</html>
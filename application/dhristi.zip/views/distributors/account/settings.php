<main class="mdl-layout__content">
	<div class="mdl-grid">
		<div class="mdl-cell mdl-cell--4-col">
			<div class="mdl-card mdl-shadow--2dp">
                <div class="mdl-card__title mdl-card--expand">
                    <h2 class="mdl-card__title-text">Initialize Transactions</h2>
                </div>
                <div class="mdl-card__supporting-text">
                    <div class="mdl-grid">
                        <div class="mdl-cell mdl-cell--12-col">
                            <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect" for="del_txns">
                                <input type="checkbox" id="del_txns" class="mdl-switch__input">
                                <span class="mdl-switch__label">Delete Transactions</span>
                            </label>
                        </div>
                        <div class="mdl-cell mdl-cell--12-col">
                            <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect" for="del_inventory">
                                <input type="checkbox" id="del_inventory" class="mdl-switch__input">
                                <span class="mdl-switch__label">Delete Inventory</span>
                            </label>
                        </div>
                        <div class="mdl-cell mdl-cell--12-col">
                            <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect" for="del_godown">
                                <input type="checkbox" id="del_godown" class="mdl-switch__input">
                                <span class="mdl-switch__label">Delete Godown</span>
                            </label>
                        </div>
                        <div class="mdl-cell mdl-cell--6-col">
                            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
        						<input type="text" data-type="date" id="del_from" class="mdl-textfield__input">
        						<label class="mdl-textfield__label" for="del_from">Select From Date</label>
        					</div>
                        </div>
                        <div class="mdl-cell mdl-cell--6-col">
                            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
        						<input type="text" data-type="date" id="del_to" class="mdl-textfield__input">
        						<label class="mdl-textfield__label" for="del_to">Select To Date</label>
        					</div>
                        </div>
                        <button class="mdl-button mdl-js-button mdl-button-done mdl-button--raised mdl-js-ripple-effect mdl-button--primary" style="width: 100%;" id="update">Proceed</button>
                        <div id="pass-disp">
                            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
        						<input type="password" id="switch_pass" name="switch_pass" class="mdl-textfield__input">
        						<label class="mdl-textfield__label" for="switch_pass">Enter your Password</label>
        					</div>
        					<button class="mdl-button mdl-js-button mdl-button--primary" id="switch-pass-btn">Update Settings</button>
    					</div>
                    </div>
                </div>
                
            </div>
		</div>
		<div class="mdl-cell mdl-cell--4-col" style="">
		    <div class="mdl-card mdl-shadow--2dp">
                <div class="mdl-card__title mdl-card--expand">
                    <h2 class="mdl-card__title-text">Password Reset</h2>
                </div>
                <div class="mdl-card__supporting-text">
                    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
						<input type="password" id="u_o_pass" name="u_o_pass" class="mdl-textfield__input">
						<label class="mdl-textfield__label" for="u_o_pass">Old Password</label>
					</div>
					<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
						<input type="password" id="u_pass" name="u_pass" class="mdl-textfield__input">
						<label class="mdl-textfield__label" for="u_pass">Password</label>
					</div>
					<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
						<input type="password" id="u_confirm_pass" name="u_confirm_pass" class="mdl-textfield__input">
						<label class="mdl-textfield__label" for="u_confirm_pass">Confirm Password</label>
					</div>
					<button class="mdl-button mdl-js-button mdl-button-done mdl-button--raised mdl-js-ripple-effect mdl-button--colored" style="width: 100%;" id="update_password">Update</button>
                </div>
                
            </div>
		</div>
		<div class="mdl-cell mdl-cell--4-col" style="">
		    <div class="mdl-card mdl-shadow--2dp">
                <div class="mdl-card__title mdl-card--expand">
                    <h2 class="mdl-card__title-text">Financial Year</h2>
                </div>
                <div class="mdl-card__supporting-text">
					<button class="mdl-button mdl-js-button mdl-js-ripple-effect" style="" id="manage_financial">Manage <i class="material-icons">arrow_right</i></button>
                </div>
                
            </div>
		</div>
		<div class="mdl-cell mdl-cell--4-col" id="user-create-div" style="display:none;">
		    <div class="mdl-card mdl-shadow--2dp">
                <div class="mdl-card__title mdl-card--expand">
                    <h2 class="mdl-card__title-text">Create Users</h2>
                </div>
                <div class="mdl-card__supporting-text">
                    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
						<input type="text" id="cu_name" name="cu_name" class="mdl-textfield__input">
						<label class="mdl-textfield__label" for="cu_name">Name</label>
					</div>
					<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
						<input type="text" id="cu_email" name="cu_email" class="mdl-textfield__input">
						<label class="mdl-textfield__label" for="cu_email">Email</label>
					</div>
					<button class="mdl-button mdl-js-button mdl-button-done mdl-button--raised mdl-js-ripple-effect mdl-button--accent" style="width: 100%;" id="cu_submit">Add User</button>
					<table class="mdl-data-table mdl-js-data-table mdl-shadow--2dp" style="width:100%;" id="cu_table">
                        <thead>
                            <tr>
                                <th class="mdl-data-table__cell--non-numeric">Name</th>
                                <th class="mdl-data-table__cell--non-numeric">Email</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php for($i=0;$i<count($usrs); $i++) {
                               echo '<tr><td class="mdl-data-table__cell--non-numeric">'.$usrs[$i]->idu_name.'</td><td class="mdl-data-table__cell--non-numeric">'.$usrs[$i]->idu_username.'</td><td><button class="mdl-button mdl-js-button mdl-button--icon mdl-button--colored delete" id="'.$usrs[$i]->idu_id.'"><i class="material-icons">delete</i></button></td></tr>'; 
                            }?>
                        </tbody>
                    </table>
                </div>
                
            </div>
		</div>
	</div>
	<div id="demo-snackbar-example" class="mdl-js-snackbar mdl-snackbar">
        <div class="mdl-snackbar__text"></div>
        <button class="mdl-snackbar__action" type="button"></button>
    </div>
</div>
</div>
</body>
<script>
	var fromdy, frommn, fromyr, tody, tomn, toyr;
	$(document).ready(function() {
	    $('#del_from').bootstrapMaterialDatePicker({ weekStart : 0, time: false });
	    $('#del_to').bootstrapMaterialDatePicker({ weekStart : 0, time: false });
	    $('#yr_from_dy').bootstrapMaterialDatePicker({ weekStart : 0, time: false }).on('change', function(e, date) {
	    	var rt = new Date(date._d);
	    	fromdy = rt.getDate();
	    	frommn = rt.getMonth();
	    	fromyr = rt.getFullYear();
	    });
	    $('#yr_to_dy').bootstrapMaterialDatePicker({ weekStart : 0, time: false }).on('change', function(e, date) {
	    	var rt = new Date(date._d);
	    	tody = rt.getDate();
	    	tomn = rt.getMonth();
	    	toyr = rt.getFullYear();
	    });
	    
	    <?php 
    		if(!isset($txn)) {
    			echo "var dt = new Date();";
    			echo "var s_dt = dt.getFullYear() + '-' + (dt.getMonth() + 1) + '-' + dt.getDate();";
    			
    			echo "$('#del_from').val(s_dt);";
    			echo "$('#del_to').val(s_dt);";
    		}
    	?>
	    
	    <?php 
	        $sess_data = $this->session->userdata();
	        if(isset($sess_data['sub'])) {
	            echo '$("#user-create-div").css("display","none");';
	        }
	    ?>
	    
	    $('#pass-disp').css('display','none');
	    
	    $('#update').click(function(e) {
	        e.preventDefault();
	        $('#pass-disp').css('display','block');
	    });
	    
	    $('#switch-pass-btn').click(function(e) {
	        e.preventDefault();
	        
	        var ps = $('#switch_pass').val();
	        $.post('<?php echo base_url().$type."/Account/delete_txns"; ?>', { 'ps' : ps, 't' : $('#del_txns')[0].checked, 'i' : $('#del_inventory')[0].checked, 'g' : $('#del_godown')[0].checked, 'from' : $('#del_from').val(), 'to': $('#del_to').val() }, function(d, s, x) { 
	            if(d=="true") {
	                display_message("Done.");
	            } else if(d=="false") { 
	                display_message("Failed."); 
	            } else if(d=="password") { 
	                display_message("Incorrect Password.");
	            } 
	            $('#pass-disp').css('display','none'); 
	            $('#switch_pass').val('');
	        }, 'text');
	    });
	    
	    $('#update_password').click(function(e) {
	        e.preventDefault();
	        
	        $.post('<?php $sess_data = $this->session->userdata(); if(isset($sess_data['sub'])) { echo base_url().$type."/Account/reset_account_pass/sub"; } else { echo base_url().$type."/Account/reset_account_pass"; } ?>', { 'upass' : $('#u_pass').val(), 'uopass' : $('#u_o_pass').val() }, function(d, s, x) {  if(d=="true") {display_message("Password Updated. Please Login Again"); window.location = "<?php echo base_url().$type.'/Account/logout/1'; ?>" } else if(d=="false") { display_message("Error."); } else if(d=="password") { display_message("Incorrect Password."); } }, 'text');
	    });
	    
	    $('#cu_submit').click(function(e) {
	        e.preventDefault();
	        
	        $.post('<?php echo base_url().$type."/Account/save_user"; ?>', { 'name' : $('#cu_name').val(), 'email' : $('#cu_email').val() }, function(d, s, x) { $('#cu_table > tbody').empty(); var a=JSON.parse(d), o=""; for(var i=0;i<a.length; i++) { o+='<tr><td class="mdl-data-table__cell--non-numeric">' + a[i].idu_name + '</td><td class="mdl-data-table__cell--non-numeric">' + a[i].idu_username + '</td><td><button class="mdl-button mdl-js-button mdl-button--icon mdl-button--colored delete" id="' + a[i].idu_id + '"><i class="material-icons">delete</i></button></td></tr>';  } $('#cu_table > tbody').append(o); reset_users()  }, 'text');
	    });
	    
	    $('#cu_table').on('click','.delete', function(e) {
	        e.preventDefault();
	        
	        $.post('<?php echo base_url().$type."/Account/delete_user"; ?>', { 'did' : $(this).prop('id') }, function(d, s, x) { $('#cu_table > tbody').empty(); var a=JSON.parse(d), o=""; for(var i=0;i<a.length; i++) { o+='<tr><td class="mdl-data-table__cell--non-numeric">' + a[i].idu_name + '</td><td class="mdl-data-table__cell--non-numeric">' + a[i].idu_username + '</td><td><button class="mdl-button mdl-js-button mdl-button--icon mdl-button--colored delete" id="' + a[i].idu_id + '"><i class="material-icons">delete</i></button></td></tr>';  } $('#cu_table > tbody').append(o); reset_users(); }, 'text');
	    });
	    
	    $('#manage_financial').click(function(e) {
	    	e.preventDefault();
	    	window.location = "<?php echo base_url().$type.'/Account/manage_financial'; ?>";
	    })
	    
	});
	
	function reset_users() {
	
	    $('#cu_name').val('');
	    $('#cu_email').val('');
	}
	function switchon(){
	    document.getElementById('switch-1').checked = true;
	   // $("#switch-1").prop( "checked", true );
	    console.log("Ahoy");
	}
	
	function switchoff(){
	    $("#switch-1").prop( "checked", false );
	}
	
	
	function display_message(message) {
	    var snackbarContainer = document.querySelector('#demo-snackbar-example');
        var ert = {message: message,timeout: 2000, }; 
        
        snackbarContainer.MaterialSnackbar.showSnackbar(ert);

	}
	function redirect() {
		window.location = '<?php echo base_url().$this->config->item('dealer_login_red'); ?>';
	}
</script>
</html>
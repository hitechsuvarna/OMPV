<style>
	
    a {
        color: #fff;
        text-decoration: none;
    }

    a:hover {
        color: #fff;
        text-decoration: none;
    }

    table > tr > td > a {
        color: #0033cc !important;
        text-decoration: none;
    }

    a:hover {
        color: #fff;
        text-decoration: none;
    }

    /*html, body {
        height: 100%;
        width: 100%;
        margin: 0;
        padding: 0;
        overflow: hidden;
    }*/
    
    .product_qty {
        border: 1px solid #999;
        border-radius: 3px;
        padding: 10px;
        text-align: center;
        margin-bottom: 10px;
        width: 70px;
    }

    .pending_orders_row {
        padding: 20px;
    }

    .pro {
        text-align: left !important;
    }

    /*header {
        background-color: #fff !important;
        color: #000 !important;
        box-shadow: 0px 0px 0px #fff !important;
    }

    .mdl-layout-title, .mdl-layout__drawer-button {
        color: #000 !important;
    }*/

</style>
<main class="mdl-layout__content">
	<div class="mdl-grid" id="transactions">
        <div class="mdl-cell mdl-cell--4-col outstanding" id="out_sale">
            <div class="mdl-card mdl-shadow--4dp">
                <!-- <div class="mdl-card__title mdl-card--expand"> -->
                    <h4>
                        Todays Sales:<br>
                        <h2>Rs.<?php echo ($sale_amount='')? $sale_amount : "0"; ?>/-</h2><br>
                    </h4>
                <!-- </div> -->
            </div>
        </div>
        <div class="mdl-cell mdl-cell--4-col outstanding" id="out_delivery">
            <div class="mdl-card mdl-shadow--4dp">
                <!-- <div class="mdl-card__title mdl-card--expand"> -->
                    <h4>
                        Todays Delivery:<br>
                        <h2>Rs.<?php echo ($delivery_amount !='')? $delivery_amount : "0"; ?>/-</h2><br>
                    </h4>
                <!-- </div> -->
            </div>
        </div>
        <div class="mdl-cell mdl-cell--4-col outstanding" id="out_order">
            <div class="mdl-card mdl-shadow--4dp">
                <!-- <div class="mdl-card__title mdl-card--expand"> -->
                    <h4>
                        Outstanding- Order pending:<br>
                        <h2>Rs.<?php echo ($order_pending_amount[0]->a !='')? $order_pending_amount[0]->a : "0"; ?>/-</h2><br>
                    </h4>
                <!-- </div> -->
            </div>
        </div>
        <div class="mdl-cell mdl-cell--4-col" id="pending_orders">
            <div class="mdl-card mdl-shadow--4dp">
                <div class="mdl-card__title">
                    <h2 class="mdl-card__title-text">
                        Pending Orders
                    </h2>
                </div>
                <div class="mdl-card__supporting-text">
                    <table style="width: 100%; display: block; overflow: auto;" class="mdl-data-table mdl-js-data-table">
                        <?php 
                            for ($i=0; $i < count($pending) ; $i++) { 
                                echo '<tr><td style="width:100%; text-align:left;"><a href="'.base_url().$type.'/Transactions/order_details/'.$pending[$i]->it_id.'" style="color: #0033cc;">#'.$pending[$i]->it_txn_no.' - '.$pending[$i]->ic_name.'</a></td><td>'.$pending[$i]->it_date.'</td><td>Rs.'.$pending[$i]->it_amount.'/-</td> </tr>';
                            }
                        ?>
                    </table>
                </div>
            </div>
        </div>
        <div class="mdl-cell mdl-cell--12-col" id="order_products">
            <div class="mdl-card mdl-shadow--4dp">
                <div class="mdl-card__title">
                    <h2 class="mdl-card__title-text">
                        Products that you need to order urgently.
                    </h2>
                </div>
                <div class="mdl-card__supporting-text">
                    <table style="width: 100%; display: block; overflow: auto;" class="mdl-data-table mdl-js-data-table order_table">
                        <thead>
                            <tr>
                                <th class="pro">Product</th><th>Available</th><th>Order Qty</th>
                            </tr>    
                        </thead>
                        <tbody>
                            <?php 
                                // print_r($order_products);
                                for ($i=0; $i < count($order_products); $i++) { 
                                    echo '<tr><td style="width:100%;" class="pro"><input class="ord_name" id="nm'.$order_products[$i]['id'].'" type="text" style="border:1px solid #aaa; border-radius:5px; padding:10px; width:100%;" readonly value="'.$order_products[$i]['product'].'"></td><td>'.$order_products[$i]['balance'].'</td><td><input class="ord_qty" type="text" id="'.$order_products[$i]['id'].'" style="border:1px solid #aaa; padding:10px; border-radius:5px; text-align:center;"></tr>';
                                }
                            ?>    
                        </tbody>
                    </table>
                    <button class="mdl-button mdl-js--button mdl-button--colored mdl-button--raised" id="print_list">Print List</button>
                </div>
            </div>
        </div>
    </div>
</main>
</div>

</body>
<script type="text/javascript">
    var date = new Date();
    var order_list = [], order_txt= date + '<br><style>table { width:100%; border: 1px solid #aaa; border-radius: 5px; } table > tbody > tr > td { border-top:1px solid #aaa; } </style><table><thead><tr><th>Product</th><th>Qty</th></tr></thead><tbody>';
    $(document).ready( function() {
        
    
        $('#print_list').click(function(e) {
            e.preventDefault();
            $('.ord_qty').each(function() {
                if($(this).val() != "") {
                    var x = '#nm' + $(this).prop('id');
                    order_list.push({ 'id' : $(this).prop('id'), 'name' : $(x).val(), 'qty' : $(this).val()});    
                }
            });
            fill_list();
            print_reciept();
        });
        
        function fill_list() {
            for(var i=0;i<order_list.length;i++) {
                order_txt+='<tr><td>' + order_list[i].name + '</td><td>' + order_list[i].qty + '</td></tr>';
            }
            order_txt +='</tbody></table>';
        }
        
        function print_reciept() {
    		var mywindow = window.open('', 'Order List', fullscreen=1);
    		mywindow.document.write(order_txt); mywindow.document.close(); mywindow.focus(); mywindow.print(); mywindow.close();
    	}
        
        $('.block').click(function(e) {
            console.log($(this).prop('id'));
        });

        <?php 
            if($oid != $rid ) { echo "$('.outstanding').css('display','none');$('#order_products').css('display','none');$('#pending_orders').css('display','none'); "; } else {
            if (count($sale_amount) > 0) { echo "$('.outstanding').css('display','block');"; } else {  echo "$('#outstanding').css('display','none');"; }

            if (count($order_pending_amount) > 0) { echo "$('#pending_orders').css('display','block');"; } else {  echo "$('#pending_orders').css('display','none');"; } }

        ?>
    });
</script>
</html>
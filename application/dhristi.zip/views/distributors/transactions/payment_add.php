<style type="text/css">
	.purchase_table {
		width: 100%;
        text-align: left;
        border: 0px solid #ccc;
        border-collapse: collapse;
        
	}

	@media only screen and (max-width: 760px) {
		.purchase_table {
			display: block;
        	overflow: auto;
		}
	}

	.purchase_table > thead > tr {
		box-shadow: 0px 5px 5px #ccc;
	}

	.purchase_table > thead > tr > th {
		padding: 10px;
	}

	.purchase_table > tbody > tr {
		border-bottom: 1px solid #ccc;
	}

	.purchase_table > tbody > tr > td {
		padding: 15px;
	}

	.cart_table_details {
		width: 100%;
	}
	.amount {
		text-align: right;
	}

	#order_number {
		color: #ff0000;
	}

	#total_amount {
		color: #ff0000;
	}

	.product_qty {
        border: 1px solid #999;
        border-radius: 3px;
        padding: 10px;
        text-align: center;
        margin-bottom: 10px;
        width: 70px;
    }
    
    #dealers {
        width: 100%;
        text-align: left;
        border: 0px solid #ccc;
        border-collapse: collapse;
    }

    #dealers > thead > tr {
        box-shadow: 0px 5px 5px #ccc;
    }

    #dealers > thead > tr > th {
        padding: 10px;
    }

    #dealers > tfoot {
        box-shadow: 0px 5px 5px #ccc;
    }

    #dealers > tfoot > tr > th {
        padding: 10px;
    }

    #dealers > tbody > tr > td {
        padding: 15px;
    }

    #dealers > tbody > tr {
        border-bottom: 1px solid #ccc;
    }

    #dealers > tbody > tr > td > a {
        color: #ff0000;
        text-decoration: none;
    }
</style>

<main class="mdl-layout__content">
    <div class="mdl-grid" style="display:non;">
		<div class="mdl-cell mdl-cell--4-col">
			<div class="mdl-card mdl-shadow--4dp">
				<div class="mdl-card__title">
					<h2 class="mdl-card__title-text">1. Search Contact</h2>
				</div>
				<div class="mdl-card__supporting-text" style="width: auto;">
					<div >
						<b>Select Contact</b>
						<ul id="i_contact" class="mdl-textfield__input" style="margin-top: 6px;width: auto;">
							<?php if (isset($edit_txn)) {
									echo "<li>".$edit_txn[0]->itp_mode."</li>";
								}
							?>
						</ul>
					</div>
		        </div>
		    </div>
		</div>
		<div class="mdl-cell mdl-cell--8-col">
			<div class="mdl-card mdl-shadow--4dp">
				<div class="mdl-card__title">
					<h2 class="mdl-card__title-text">2. View & Select Transactions</h2>
				</div>
				<div class="mdl-card__supporting-text" style="width: auto;">
					<table style="width: 100%; display: block; overflow: auto;" class="mdl-data-table mdl-js-data-table" id="pay_txns">
					    
					</table>
		        </div>
		    </div>
		</div>
		<div class="mdl-cell mdl-cell--4-col">
			<div class="mdl-card mdl-shadow--4dp">
				<div class="mdl-card__title">
					<h2 class="mdl-card__title-text">Payment Details</h2>
				</div>
				<div class="mdl-card__supporting-text" style="width: auto;">
				    <div>
				        Total Selected Amount:
				        <h4 id="total_amt"></h4>
				    </div>
					<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
						<input type="text" data-type="date" id="i_pay_date" class="mdl-textfield__input" value="<?php if(isset($edit_txn)) { echo $edit_txn[0]->itp_date; } ?>">
						<label class="mdl-textfield__label" for="i_pay_date">Select Payment Date</label>
					</div>
					<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label" style="padding:0px;text-align:left;width:auto;">
						<b>Mode of Payment</b>
						<ul id="i_pay_mode" class="mdl-textfield__input" style="margin-top: 6px;width: auto;">
							<?php if (isset($edit_txn)) {
									echo "<li>".$edit_txn[0]->itp_mode."</li>";
								}
							?>
						</ul>
					</div>
					<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
						<textarea id="i_txn_desc" class="mdl-textfield__input"><?php if(isset($edit_txn)) { echo $edit_txn[0]->itp_details; } ?></textarea>
						<label class="mdl-textfield__label" for="i_pay_desc">Payment Description</label>
					</div>
					<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
						<input type="text" id="i_pay_amt" class="mdl-textfield__input" value="<?php if(isset($edit_txn)) { echo $edit_txn[0]->itp_amt; } ?>">
						<label class="mdl-textfield__label" for="i_pay_amt">Payment Amount</label>
					</div>
				</div>
			</div>
		</div>
		<div class="mdl-cell mdl-cell--4-col">
			<div class="mdl-card mdl-shadow--4dp">
				<div class="mdl-card__title">
					<h2 class="mdl-card__title-text">Payment History for this transaction</h2>
				</div>
				<div class="mdl-card__supporting-text" style="width: auto;">
		            <table style="width: 100%; display: block; overflow: auto;" class="mdl-data-table mdl-js-data-table" id="pay_history">
                        
                    </table>
		        </div>
		    </div>
		</div>
	</div>
	<button class="lower-button mdl-button mdl-button-done mdl-js-button mdl-button--fab mdl-js-ripple-effect mdl-button--accent" id="submit">
		<i class="material-icons">done</i>
	</button>
</div>
</div>
</body>
<script type="text/javascript">
	var product_name = [];
	var product_qty = [];
	var product_rate = [];
	var product_amount = [];
	var edit_index = 0;
	var edit_flag = false;
	
	var table_select = [];
	var contact_select = "";
	
	$(document).ready( function() {
    	var mode_data = [];
    	
    	<?php
    		for ($i=0; $i < count($modes) ; $i++) { 
    			echo "mode_data.push('".$modes[$i]->itp_mode."');";
    		}
    	?>
    	
    	$('#i_pay_mode').tagit({
    		autocomplete : { delay: 0, minLenght: 5},
    		allowSpaces : true,
    		availableTags : mode_data,
    		tagLimit : 1,
    		singleField : true
    	});
    	
    	var contact_data = [];
    	
    	<?php
    		for ($i=0; $i < count($contacts) ; $i++) { 
    			echo "contact_data.push('".$contacts[$i]->ic_name."');";
    		}
    	?>

    	$('#i_contact').tagit({
    		autocomplete : { delay: 0, minLenght: 5},
    		allowSpaces : true,
    		availableTags : contact_data,
    		tagLimit : 1,
    		singleField : true,
    		afterTagAdded : (function(event, ui) {
    		    contact_select = ui.tag[0].innerText;
    			get_txns($('#i_type').val(), ui.tag[0].innerText);
    			console.log(contact_select);
    		}),
    		afterTagRemoved : (function(event, ui) {
    		    contact_select = "";
    			get_txns($('#i_type').val(), "");
    			console.log(contact_select);
    		})
    	});
    });
</script>
<script>
	$('#i_pay_date').bootstrapMaterialDatePicker({ weekStart : 0, time: false });
	
	<?php 
		if(!isset($edit_txn)) {
			echo "var dt = new Date();";
			echo "var s_dt = dt.getFullYear() + '-' + (dt.getMonth() + 1) + '-' + dt.getDate();";
			
			echo "$('#i_pay_date').val(s_dt);";
		}
	?>
</script>
<script>
    var txnid = 0;
    var totamt = 0;
	$(document).ready(function() {
	    
	    $('#i_pay_contact').keyup(function(e) {
            e.preventDefault();
            get_txns($('#i_type').val(), $(this).val()); 
        });
        
        $('#pay_txns').on('click','.view_invoice', function(e) {
            e.preventDefault();
            window.location = "<?php echo base_url().$type.'/Transactions/invoice_edit/'; ?>"  + $(this).prop('id');
        });
        $('#pay_txns').on('click','.view_purchase', function(e) {
            e.preventDefault();
            window.location = "<?php echo base_url().$type.'/Transactions/purchase_edit/'; ?>"  + $(this).prop('id');
        });
        $('#pay_txns').on('click','.view_cd_note', function(e) {
            e.preventDefault();
            window.location = "<?php echo base_url().$type.'/Transactions/cd_note_edit/'; ?>"  + $(this).prop('id');
        });
        
        
        $('#pay_txns').on('click', 'tr', function(e) {
            e.preventDefault();
            txnid = $(this).prop('id');
            
            var flg = false;
            var tmpidx = 0;
            for(var i=0;i<table_select.length; i++) {
                if(txnid == table_select[i]) {
                    flg = true;
                    tmpidx = i;
                    break;
                }
            }
            
            for(var i=0;i<txns.length;i++) {
                if(txnid == txns[i].id) {
                    if(flg == false) {
                        totamt += parseInt(txns[i].amt);
                    } else {
                        totamt -= parseInt(txns[i].amt);
                    }
                }
            }
            
            if(flg == true) {
                table_select.splice(tmpidx, 1);
                $(this).css('background-color','#fff');
                $(this).css('color','#999');
            } else {
                table_select.push(txnid);
                $(this).css('background-color','#003399');
                $(this).css('color','#fff');
            }
            get_pays($(this).prop('id'));
            
        });
        
        
		$('#submit').click(function(e) {
			e.preventDefault();
			
			$.post('<?php if(isset($edit_txn)) { echo base_url().$type."/Transactions/update_payment/".$tid; } else { echo base_url().$type."/Transactions/save_payment/"; } ?>', {
			    'tid': table_select,
			    'date' : $('#i_pay_date').val(), 
			    'mode' : $('#i_pay_mode')[0].innerText, 
			    'details' : $('#i_txn_desc').val(), 
			    'amt' : $('#i_pay_amt').val(),
			    'f' : contact_select
			}, function(d,s,x) {
			    window.location = "<?php echo base_url().$type.'/Transactions/payments'; ?>";
			}, "text");
		});
		
		$('#pay_history').on('click', '.delete', function(e) {
		    e.preventDefault();
		    delete_pay($(this).prop('id'));
		});


	});
	
	var txns = [];
	function delete_pay(ptid) {
	    $.post('<?php echo base_url().$type."/Transactions/delete_payment_transaction"; ?>', { 'ptid' : ptid }, function(d,s,x) { get_pays(); }, "text");
	}
	
	function get_txns(type, keywords) {
	    $.post('<?php echo base_url().$type."/Transactions/get_ledger_transactions"; ?>', { 'keywords' : keywords }, function(d,s,x) { 
	        $('#pay_txns').empty(); 
	        var a=JSON.parse(d), o=""; 
	        txns = []; 
	        table_select =[];
	        for(var i=0;i<a.length; i++) { 
	            var ttyp = "";
	            console.log("*" + a[i].it_type + "*");
	            if(a[i].it_type == "Purchase") {
	                o+="<tr id='" + a[i].it_id + "'><td>" + a[i].it_type + "</td><td>" + a[i].it_txn_no + "</td><td>" + a[i].it_date + "</td><td>" + a[i].it_status + "</td>";
	                ttyp = "debit";
	                o+="<td></td><td>Rs." +a[i].it_amount +  "</td><td><button class='mdl-button mdl-js-button mdl-button--raised mdl-button--colored view_purchase' id='" + a[i].it_id + "'><i class='material-icons'>visibility</i></button></td></tr>";     
	            } else if(a[i].it_type == "Sale") {
	                o+="<tr id='" + a[i].it_id + "'><td>" + a[i].it_type + "</td><td>" + a[i].it_txn_no + "</td><td>" + a[i].it_date + "</td><td>" + a[i].it_status + "</td>";
	                ttyp = "credit";
	                o+="<td>Rs." +a[i].it_amount +  "</td><td></td><td><button class='mdl-button mdl-js-button mdl-button--raised mdl-button--colored view_invoice' id='" + a[i].it_id + "'><i class='material-icons'>visibility</i></button></td></tr>";     
	            } else if(a[i].it_type == "Credit Note") {
	                o+="<tr id='" + a[i].it_id + "'><td>" + a[i].it_type + "</td><td>" + a[i].it_txn_no + "</td><td>" + a[i].it_date + "</td><td>" + a[i].it_status + "</td>";
	                ttyp = "debit";
	                o+="<td></td><td>Rs." +a[i].it_amount +  "</td><td><button class='mdl-button mdl-js-button mdl-button--raised mdl-button--colored view_cd_note' id='" + a[i].it_id + "'><i class='material-icons'>visibility</i></button></td></tr>";     
	            } else if(a[i].it_type == "Debit Note") {
	                o+="<tr id='" + a[i].it_id + "'><td>" + a[i].it_type + "</td><td>" + a[i].it_txn_no + "</td><td>" + a[i].it_date + "</td><td>" + a[i].it_status + "</td>";
	                ttyp = "credit";
	                o+="<td>Rs." +a[i].it_amount +  "</td><td></td><td><button class='mdl-button mdl-js-button mdl-button--raised mdl-button--colored view_cd_note' id='" + a[i].it_id + "'><i class='material-icons'>visibility</i></button></td></tr>";     
	            }
	            console.log(ttyp);
	            
	            if(ttyp == "credit") {
	                txns.push({ 'id' : a[i].it_id, 'amt' : a[i].it_amount });
	            } else if(ttyp == "debit") {
	                txns.push({ 'id' : a[i].it_id, 'amt' : (a[i].it_amount*-1) });
	            }
	            
	        } 
	        $('#pay_txns').append(o);  
	        <?php if(isset($edit_txn)) echo "$('#i_txns').val('".$edit_txn[0]->itp_t_id."'); get_pays(".$edit_txn[0]->itp_t_id.")"; ?> 
	    }, "text");
	}
	
	function get_pays() {
	    $.post('<?php echo base_url().$type."/Transactions/get_payment_history"; ?>', { 'tid' : table_select }, function(d,s,x) { $('#pay_history').empty(); var a=JSON.parse(d), o=""; for(var i=0;i<a.length; i++) { if(a[i].it_type=="Purchase") { totamt+= parseInt(a[i].itp_amt); } else { totamt-=parseInt(a[i].itp_amt); } o+='<tr><td><button class="mdl-button mdl-js-button mdl-button--icon mdl-button--colored delete" id="' + a[i].itp_id + '"><i class="material-icons">delete</i></button></td><td style="text-align:left;">#' + a[i].it_txn_no + '</td><td style="text-align:left;">' + a[i].itp_date + '</td><td>' + a[i].itp_amt + '</td><td>' + a[i].itp_mode + '</td><td style="text-align:left;">' + a[i].itp_details + '</td></tr>'; } $('#pay_history').append(o); $('#total_amt').empty(); $('#total_amt').append(totamt);}, "text");
	}
</script>
</html>
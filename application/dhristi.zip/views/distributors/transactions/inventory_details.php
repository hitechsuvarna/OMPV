<style type="text/css">
	.transactions {
		width: 100%;
		border: none;
		padding: 10px;
		border: 1px solid #999;
		border-collapse: collapse;
		display: block;
		overflow: auto;
	}

	.transactions > thead > tr {
		box-shadow: 1px 5px 5px #ccc;
	}

	.transactions > thead > tr > th {
		padding: 10px;
	}

	.transactions > tbody > tr {
		width: 100%;
	}

	.transactions > tbody > tr > td {
		border-bottom: 1px solid #999;
		padding: 15px;
		width: 100%;
	}

	.cart_table_details {
		width: 100%;
	}
	.amount {
		text-align: right;
	}

	.order_number {
		color: #ff0000;
	}

	#total_amount {
		color: #ff0000;
	}

	.product_qty {
        border: 1px solid #999;
        border-radius: 3px;
        padding: 10px;
        text-align: center;
        margin-bottom: 10px;
        width: 70px;
    }

    .stock_display > h4	 {
    	text-align: center;
    }

    .stock_display > table {
    	width: 100%;
    }

</style>

<main class="mdl-layout__content">
	<div class="mdl-grid stock_display">
		<table>
			<tr>
				<td><h4>Available Stock: <?php echo $bal;?></h4></td>
				<td><button class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored" id="reconcile"> Reconcile </button></td>
			</tr>
		</table>
	</div>
	<div class="mdl-grid stock_transaction">
		<table class="transactions">
			<thead>
				<tr>
					<th>Particulars</th>
					<th>Txn Number</th>
					<th>Txn Date</th>
					<th>Credit</th>
					<th>Debit</th>
					<th>Rate</th>
				</tr>
			</thead>
			<tbody>
				<?php for ($i=0; $i < count($txn); $i++) { 
					echo '<tr> <td>'.$txn[$i]->ic_name.'</td> <td>';
					if($txn[$i]->it_txn_no != "") { echo $txn[$i]->ii_order_id.'</td><td>'.$txn[$i]->it_date.'</td>'; } else { echo $txn[$i]->ii_txn_num.'</td> <td>'.$txn[$i]->ii_txn_date.'</td>'; }
					if ($txn[$i]->ii_type == "credit") {
						echo '<td>'.$txn[$i]->ii_inward.'</td><td></td>';
					} else {
						echo '<td></td><td>'.$txn[$i]->ii_outward.'</td>';
					}
					echo '<td>'.$txn[$i]->itp_rate.'</td> </tr>';
				} ?>
			</tbody>
		</table>
	</div>
    <div id="demo-snackbar-example" class="mdl-js-snackbar mdl-snackbar">
        <div class="mdl-snackbar__text"></div>
        <button class="mdl-snackbar__action" type="button"></button>
    </div>
</main>
</div>
</div>
</body>
<script>
    var snackbarContainer = document.querySelector('#demo-snackbar-example');
    
	$(document).ready(function() {
		$('.stock_display').on('click', '.stock_item', function(e) {
			e.preventDefault();

			window.location = "<?php echo base_url().$type.'/Transactions/inventory_details/'; ?>" + $(this).prop('id');
		});
		
		$('#reconcile').click(function(e) {
		    e.preventDefault();
		   
		    $.post('<?php echo base_url().$type."/Transactions/reconcile_inventory/".$pid; ?>', {}, function(d,s,x) {
		        var ert = {message: 'Stocks Reconciled.',timeout: 2000, }; 
                snackbarContainer.MaterialSnackbar.showSnackbar(ert);
                location.reload();
		    }) 
		});
	});
</script>
</html>
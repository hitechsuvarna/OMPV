<style type="text/css">
	a {
        color: #fff;
        text-decoration: none;
    }

    a:hover {
        color: #fff;
        text-decoration: none;
    }

    /*html, body {
        height: 100%;
        width: 100%;
        margin: 0;
        padding: 0;
        overflow: hidden;
    }*/
    
    #products {
        width: 100%;
        text-align: left;
        border: 0px solid #ccc;
        border-collapse: collapse;
    }

    #products > thead > tr {
        box-shadow: 0px 5px 5px #ccc;
    }

    #products > thead > tr > th {
        padding: 10px;
    }

    #products > tbody > tr > td {
        padding: 15px;
    }

    #products > tbody > tr {
        border-bottom: 1px solid #ccc;
    }

    #products > tbody > tr > td {
        color: #666;
        text-decoration: none;
    }

</style>

<main class="mdl-layout__content">
    <div class="mdl-grid">
        <div class="mdl-cell mdl-cell--6-col">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
				<select id="p_category" class="mdl-textfield__input">
				    <option value="0">All</option>
				    <?php 
				        for($i=0;$i<count($category); $i++) {
				            echo '<option value="'.$category[$i]->ica_id.'">'.$category[$i]->ica_category_name.'</option>';
				        }
				    ?>
				</select>
				<label class="mdl-textfield__label" for="p_name">Select Category</label>
			</div>
        </div>
        <div class="mdl-cell mdl-cell--6-col" style="text-align:right;">
            <button class="mdl-button mdl-js-button mdl-button--colored" id="reconcile"> Reconcile </button>
        </div>
    </div>
	<div class="mdl-grid">
	    <table id="products">
            <thead>
                <tr>
                    <th>Dealer</th>
                    <th>Balance</th>
                </tr>
            </thead>
            <tbody>
                <?php for ($i=0; $i < count($txn) ; $i++) { 
                    echo '<tr id="'.$txn[$i]['id'].'"> <td>'.$txn[$i]['product'].'</td><td>'.$txn[$i]['balance'].'</td></tr>';
                    }
                ?>
            </tbody>
        </table>
	</div>
	<button class="lower-button mdl-button mdl-button-done mdl-js-button mdl-button--fab mdl-js-ripple-effect mdl-button--accent" id="submit">
		<i class="material-icons">add</i>
	</button>
	<div id="demo-snackbar-example" class="mdl-js-snackbar mdl-snackbar">
        <div class="mdl-snackbar__text"></div>
        <button class="mdl-snackbar__action" type="button"></button>
    </div>
</div>
</div>
</body>
<script>
	$(document).ready(function() {
	    var snackbarContainer = document.querySelector('#demo-snackbar-example');
        $('#p_category').change(function(e) {
	        e.preventDefault();
	       
	        $.post('<?php echo base_url().$type."/Transactions/filter_inventory"; ?>', {
	            'search' : $(this).val()
	        }, function(d,s,x) {
	            console.log(d);
	            var a = JSON.parse(d), b="";
	            $('#products > tbody').empty();
	            for(var i=0;i<a.length;i++) {
	                b+='<tr id="' + a[i].id +'"><td>' + a[i].product + '</td><td>' + a[i].balance + '</td></tr>';
	            }
	            $('#products > tbody').append(b);
	        }, "text");
	    });
	    
	    $('#reconcile').click(function(e) {
		    e.preventDefault();
		   
		    $.post('<?php echo base_url().$type."/Transactions/reconcile_inventory/"; ?>', {}, function(d,s,x) {
		        var ert = {message: 'Stocks Reconciled.',timeout: 2000, }; 
                snackbarContainer.MaterialSnackbar.showSnackbar(ert);
                location.reload();
		    }) 
		});
		
	    $('#fixed-header-drawer-exp').keyup(function(e) {
            $.post('<?php echo base_url().$type."/Transactions/search_inventory"; ?>', {
                'keywords' : $(this).val()
            }, function(data, status, xhr) {
                var a = JSON.parse(data), s = ""; $('#products > tbody').empty();
                for (var i = 0; i < a.length; i++) {
                    s+="<tr id='" + a[i].id + "'><td>" + a[i].product + "</td><td>" + a[i].balance + "</td></tr>";
                }
                $('#products > tbody').append(s);
            }, "text");
        });

        $('#submit').click(function(e) {
            e.preventDefault();
            
            window.location = "<?php echo base_url().$type.'/Transactions/add_inventory'; ?>";
        });
        
		$('#products').on('click', 'tr', function(e) {
			e.preventDefault();
			window.location = "<?php echo base_url().$type.'/Transactions/inventory_details/'; ?>" + $(this).prop('id');
		})
	});
</script>
</html>
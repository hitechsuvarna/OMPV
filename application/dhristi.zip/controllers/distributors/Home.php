<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct()	{
		parent:: __construct();
		$this->load->database();
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->library('email');
		$this->load->model('distributors/Transaction_Model','txn_model');
		$this->load->dbforge();
	}
########## USER ACCOUNT, LOGIN, VERIFY AND LOGOUT ################
	public function index() {
		$sess_data = $this->session->userdata();
		if(isset($sess_data['user_details'][0])) {
			$rid = $sess_data['user_details'][0]->iu_ref;
			$oid = $sess_data['user_details'][0]->iu_owner;
			if(!$sess_data['fy']) {
				redirect(base_url().'distributors/Account/settings');
			}

			$fy = $sess_data['fy'][0]->ify_start_date;
			$ty = $sess_data['fy'][0]->ify_end_date;
			

			$data['oid'] = $oid;
			$data['rid'] = $rid;
			$dt = date('Y-m-d');
			
			$query = $this->db->query("SELECT it_id, it_amount, it_order_txn FROM i_txns WHERE it_type='Sale' AND it_status IN ('invoiced','paid') AND it_owner='$oid' AND it_date BETWEEN '$fy' AND '$ty' AND it_date='$dt'");
			$result = $query->result(); $tot=0;
			for($i=0;$i<count($result); $i++) {
			    $tot+=$result[$i]->it_amount;
			}
			$data['sale_amount'] = $tot;
			
			$tot=0;
			$query = $this->db->query("SELECT it_id, it_amount FROM i_txns WHERE it_type='Delivery' AND it_status IN ('delivery','shipping','approved') AND it_owner='$oid' AND it_date BETWEEN '$fy' AND '$ty' AND it_date='$dt'");
			$result1 = $query->result();
			for($i=0;$i<count($result1); $i++) {
			    if(count($result) > 0) {
			        for($j=0;$j<count($result);$j++){
    			        if($result1[$i]->it_id != $result[$j]->it_order_txn) {
    			            $tot+=$result1[$i]->it_amount;
    			        }  
    			    }       
			    } else {
			        $tot+=$result1[$i]->it_amount;
			    }
			}
			
			$data['delivery_amount'] = $tot;
			
			$query = $this->db->query("SELECT SUM(it_amount) AS a FROM i_txns WHERE it_type='Orders' AND it_status IN ('pending') AND it_owner='$oid' AND it_date BETWEEN '$fy' AND '$ty'");
			$data['order_pending_amount'] = $query->result();
			
			$data['pending'] = $this->txn_model->load_transactions($oid, 'Sale', 'pending', null, $fy, $ty);
			$x = $this->txn_model->load_inventory_summary($oid, $rid, null, null, 10);
			$data['order_products'] = [];

			for ($i=0; $i < count($x); $i++) { 
				if ($x[$i]['balance'] <= $x[$i]['threshold']) {
					array_push($data['order_products'], $x[$i]);
				}
			}

			$ert['name'] = $sess_data['user_details'][0]->ic_name;
			$ert['title'] = "Home";
			$ert['search'] = "true";
			$ert['search_placeholder'] = "Search Products";
			$ert['type'] = "distributors";
			
			$this->load->view('distributors/navbar', $ert);
			$this->load->view('distributors/home/home', $data);
		} else {
			redirect(base_url().'distributors/Account/login');
		}
	}

    public function new_order_notify() {
        $sess_data = $this->session->userdata();
		if(isset($sess_data['user_details'][0])) {
			$oid = $sess_data['user_details'][0]->iu_owner;
			$query = $this->db->query("SELECT * FROM i_txns WHERE it_type = 'Orders' AND it_owner='$oid' AND it_notify='pending'");
			echo count($query->result());
		}
    }
    
    public function new_dealer_notify() {
        $sess_data = $this->session->userdata();
		if(isset($sess_data['user_details'][0])) {
			$oid = $sess_data['user_details'][0]->iu_owner;
			$query = $this->db->query("SELECT * FROM i_contacts WHERE ic_section = 'Dealer' AND ic_owner='$oid' AND ic_new_flag='1'");
			echo count($query->result());
		}
    }
    
    
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Account extends CI_Controller {

	public function __construct()	{
		parent:: __construct();
		$this->load->database();
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->library('email');
		$this->load->library('excel_reader');
		$this->load->dbforge();
	}
########## LOGIN, VERIFY AND LOGOUT ################
	public function index() {
		redirect(base_url().'distributors/Account/account');
	}

	public function login() {
		$sess_data = $this->session->userdata();
		if(!isset($sess_data['user_details'][0])) {	
			
			$ert['title'] = "Login";
			$ert['search'] = "false";
			$ert['type'] = "distributors";
			// $this->load->view('distributors/navbar', $ert);
			$this->load->view('distributors/account/login', $ert);
		} else {
			redirect(base_url().'distributors/Home');
		}
	}

	public function verify() {
		$uname = $this->input->post('uname');
		$upass = $this->input->post('upass');

		$query = $this->db->query("SELECT * FROM i_users AS a LEFT JOIN i_contacts AS b ON a.iu_ref=b.ic_id LEFT JOIN i_u_access AS c ON a.iu_id=c.iua_u_id WHERE iu_username = '$uname'");
		$result = $query->result();

		if (count($result) > 0) {
		    if ($result[0]->iu_type == "distributor") {
		        if ($result[0]->iu_status == 'password_u') {
    				$id = $result[0]->iu_id;
    
    				echo $id;
    			} elseif ($result[0]->iu_password==$upass) {
    				$oid = $result[0]->iu_owner;
    				
    				$que = $this->db->query("SELECT * FROM i_financial_year WHERE ify_owner='$oid' AND ify_active='true'");
    				$data = array('status' => "user" , "user_details" => $result, "fy" => $que->result());
    				$this->session->set_userdata($data);
    
    				echo "true";
    			} else {
    				echo "false";
    			}   
		    } else {
		        echo "false";
		    }
		} else {
			echo "false";
		}
	}

	public function logout() {
		$this->session->unset_userdata('user_details');
		$this->session->unset_userdata('status');
		$this->session->unset_userdata('fy');
		redirect(base_url().'distributors/Account/login');
	}

	public function reset_password($id) {
		$data['uid'] = $id;
		$data['type'] = 'distributors';
		$this->load->view('distributors/account/reset', $data);
	}

	public function reset_update($uid) {
		$data = array('iu_password' => $this->input->post('upass'), 'iu_status' => 'active');
		$this->db->where('iu_id', $uid);
		$this->db->update('i_users', $data);
		echo "true";

	}

########## ACCOUNT DETAILS ################
	public function account() {
		$sess_data = $this->session->userdata();
		if(isset($sess_data['user_details'][0])) {
			$rid = $sess_data['user_details'][0]->iu_ref;
			$data['rid'] = $rid;
			
			$oid = $sess_data['user_details'][0]->iu_owner;
			$data['oid'] = $oid;

			$data['section'] = $sess_data['user_details'][0]->ic_section;
			$data['logo'] = $sess_data['user_details'][0]->iu_logo;
			$data['logo_sec'] = $sess_data['user_details'][0]->iu_logo_sec;

			$query = $this->db->query("SELECT * FROM i_contacts WHERE ic_id='$rid' AND ic_owner='$oid'");
			$result = $query->result();
			$data['user_info'] = $result;

			$ert['name'] = $sess_data['user_details'][0]->ic_name;			
			$ert['title'] = "Account";
			$ert['search'] = "false";
			$ert['type'] = "distributors";
			
			$this->load->view('distributors/navbar', $ert);
			$this->load->view('distributors/account/account', $data);
			
		} else {
			redirect(base_url().'distributors/Account/login');
		}
	}

	public function logo_upload($rid) {
		$sess_data = $this->session->userdata();
		if(isset($sess_data['user_details'][0])) {
			$oid = $sess_data['user_details'][0]->iu_owner;
			$upload_dir = $this->config->item('document_rt')."assets/uploads/".$oid."/logo/";
			if(!file_exists($upload_dir)) {
				mkdir($upload_dir, 0777, true);
			}
			$img_path = "";
			if (is_dir($upload_dir) && is_writable($upload_dir)) {
				$sourcePath = $_FILES['use']['tmp_name']; // Storing source path of the file in a variable
				$targetPath = $upload_dir.$_FILES['use']['name']; // Target path where file is to be stored
				// $img_path = $targetPath;
				move_uploaded_file($sourcePath,$targetPath) ; // Moving Uploaded file		
				$img_path = $_FILES['use']['name'];
			}

			$data = array('iu_logo' => $img_path);
			$this->db->where(array('iu_owner'=>$oid, 'iu_ref'=>$rid, 'iu_id' => $sess_data['user_details'][0]->iu_id ));
			$this->db->update('i_users', $data);

			$sess_data['user_details'][0]->iu_logo = $img_path;

			$this->session->set_userdata($sess_data);

			echo $rid;
		}
	}
	
	public function logo_upload_secondary($rid) {
		$sess_data = $this->session->userdata();
		if(isset($sess_data['user_details'][0])) {
			$oid = $sess_data['user_details'][0]->iu_owner;
			$upload_dir = $this->config->item('document_rt')."assets/uploads/".$oid."/logo/";
			if(!file_exists($upload_dir)) {
				mkdir($upload_dir, 0777, true);
			}
			$img_path = "";
			if (is_dir($upload_dir) && is_writable($upload_dir)) {
				$sourcePath = $_FILES['use']['tmp_name']; // Storing source path of the file in a variable
				$targetPath = $upload_dir.$_FILES['use']['name']; // Target path where file is to be stored
				// $img_path = $targetPath;
				move_uploaded_file($sourcePath,$targetPath) ; // Moving Uploaded file		
				$img_path = $_FILES['use']['name'];
			}

			$data = array('iu_logo_sec' => $img_path);
			$this->db->where(array('iu_owner'=>$oid, 'iu_ref'=>$rid, 'iu_id' => $sess_data['user_details'][0]->iu_id ));
			$this->db->update('i_users', $data);

			$sess_data['user_details'][0]->iu_logo = $img_path;

			$this->session->set_userdata($sess_data);

			echo $rid;
		}
	}
	
	

	public function update_details($rid) {
		$sess_data = $this->session->userdata();
		if(isset($sess_data['user_details'][0])) {
			$uid = $sess_data['user_details'][0]->iu_id;
			$oid = $sess_data['user_details'][0]->iu_owner;
			$dt = date('Y-m-d H:m:s');
			
			$data = array(
				'ic_name' => $this->input->post('name'),
				'ic_company' => $this->input->post('company'),
				'ic_email' => $this->input->post('email'),
				'ic_phone' => $this->input->post('phone'),
				'ic_address' => $this->input->post('address'),
				'ic_gst_number' => $this->input->post('gst'),
				'ic_bank_name' => $this->input->post('bank'),
				'ic_bank_branch' => $this->input->post('branch'),
				'ic_bank_accno' => $this->input->post('acc'),
				'ic_bank_ifsc' => $this->input->post('ifsc'),

				 );
			$this->db->where(array('ic_id' => $rid, 'ic_owner' => $oid));
			$this->db->update('i_contacts', $data);

			$data = array(
				'iu_username' => $this->input->post('email'),
			);
			$this->db->where(array('iu_id' => $uid, 'iu_ref' => $rid, 'iu_owner' => $oid));
			$this->db->update('i_users', $data);

			echo "true";
		} else {
			redirect(base_url().'distributors/Account/login');
		}
	}

########## USERS AND ACCESS ################

	public function users() {
		$sess_data = $this->session->userdata();
		if(isset($sess_data['user_details'][0])) {
			$uid = $sess_data['user_details'][0]->iu_ref;
			$data['uid'] = $uid;
			
			$oid = $sess_data['user_details'][0]->iu_owner;
			$data['oid'] = $oid;

			$query = $this->db->query("SELECT * FROM i_users AS a LEFT JOIN i_u_access AS b ON a.iu_id=b.iua_u_id LEFT JOIN i_contacts AS c ON a.iu_ref=c.ic_id WHERE a.iu_type='distributor' AND a.iu_owner='$oid'");
			$result = $query->result();
			$data['users'] = $result;

			$ert['name'] = $sess_data['user_details'][0]->ic_name;			
			$ert['title'] = "Users and Access";
			$ert['search'] = "false";
			$ert['type'] = "distributors";
			
			$this->load->view('distributors/navbar', $ert);
			$this->load->view('distributors/account/users', $data);
		} else {
			redirect(base_url().'distributors/Account/login');
		}
	}

	public function search_user() {

	}

	public function add_user() {
		$sess_data = $this->session->userdata();
		if(isset($sess_data['user_details'][0])) {
			$uid = $sess_data['user_details'][0]->iu_ref;
			$data['uid'] = $uid;
			
			$oid = $sess_data['user_details'][0]->iu_owner;
			$data['oid'] = $oid;

			$ert['name'] = $sess_data['user_details'][0]->ic_name;			
			$ert['title'] = "Users and Access";
			$ert['search'] = "false";
			$ert['type'] = "distributors";
			
			$this->load->view('distributors/navbar', $ert);
			$this->load->view('distributors/account/user_add', $data);
		} else {
			redirect(base_url().'distributors/Account/login');
		}
	}

	public function save_user() {
		$sess_data = $this->session->userdata();
		if(isset($sess_data['user_details'][0])) {
			$uid = $sess_data['user_details'][0]->iu_ref;
			$oid = $sess_data['user_details'][0]->iu_owner;
			$dt = date('Y-m-d H:m:s');
			
			$email = $this->input->post('email');
            $query = $this->db->query("SELECT * FROM i_contacts WHERE ic_email='$email'");
            $result = $query->result();
            
            if(count($result) > 0) {
                echo "exists";
            } else {
                
    			$data = array(
    				'ic_name' => $this->input->post('name'),
    				'ic_company' => $sess_data['user_details'][0]->ic_company,
    				'ic_email' => $this->input->post('email'),
    				'ic_phone' => $this->input->post('phone'),
    				'ic_address' => $this->input->post('address'),
    				'ic_owner' => $oid,
    				'ic_section' => 'Distributor User'
    				 );
    			$this->db->insert('i_contacts', $data);
    			$cid = $this->db->insert_id();
    
    			$data = array(
    				'iu_username' => $this->input->post('email'),
    				'iu_type' => 'distributor',
    				'iu_ref' => $cid,
    				'iu_owner' => $oid,
    				'iu_status' => 'password_u',
    				'iu_logo' => $sess_data['user_details'][0]->iu_logo,
    				'iu_logo_sec' => $sess_data['user_details'][0]->iu_sec_logo,
    				'iu_subscription_start' => $sess_data['user_details'][0]->iu_subscription_start,
    				'iu_subscription_end' => $sess_data['user_details'][0]->iu_subscription_end,
    				'iu_created' => $dt,
    				'iu_created_by' => $oid
    			);
    			$this->db->insert('i_users', $data);
    			$user_uid = $this->db->insert_id();
    
    			$data = array(
    				'iua_u_id' => $user_uid,
    				'iua_u_products' => $this->input->post('per_product'),
    				'iua_u_pricing' => $this->input->post('per_pricing'),
    				'iua_u_dealers' => $this->input->post('per_dealers'),
    				'iua_u_vendors' => $this->input->post('per_vendors'),
    				'iua_u_orders' => $this->input->post('per_orders'),
    				'iua_u_delivery' => $this->input->post('per_delivery'),
    				'iua_u_inventory' => $this->input->post('per_inventory'),
    				'iua_u_godown' => $this->input->post('per_godown'),
    				'iua_u_purchase' => $this->input->post('per_purchase'),
    				'iua_u_invoice' => $this->input->post('per_invoice'),
    				'iua_u_credit_note' => $this->input->post('per_credit'),
    				'iua_u_ledgers' => $this->input->post('per_ledgers'),
    				'iua_u_expenses' => $this->input->post('per_expense'),
    				'iua_u_payments' => $this->input->post('per_payments'),
    				'iua_u_tax' => $this->input->post('per_tax'),
    				'iua_u_users' => $this->input->post('per_users'),
    				'iua_u_settings' => $this->input->post('per_settings'),
    				'iua_owner' => $oid,
    				'iua_created' => $dt,
    				'iua_created_by' => $uid				
    				 );
    			$this->db->insert('i_u_access', $data);
    			echo $user_uid;
            }
		} else {
			redirect(base_url().'distributors/Account/login');
		}
	}

    public function image_upload($uid) {
		$sess_data = $this->session->userdata();
		if(isset($sess_data['user_details'][0])) {
			$oid = $sess_data['user_details'][0]->iu_owner;	
			
			$upload_dir = $this->config->item('document_rt')."assets/uploads/".$oid."/users/".$uid."/";
			if(!file_exists($upload_dir)) {
				mkdir($upload_dir, 0777, true);
			}
			$img_path = "";
			
			if (is_dir($upload_dir) && is_writable($upload_dir)) {
			    $this->db->where(array('iui_u_id' => $uid, 'iui_owner' => $oid));
			    $this->db->delete('i_u_images');
			    
			    for($ij=0; $ij < count($_FILES); $ij++) {
			        $sourcePath = $_FILES[$ij]['tmp_name']; // Storing source path of the file in a variable
    				$targetPath = $upload_dir.$_FILES[$ij]['name']; // Target path where file is to be stored
    				// $img_path = $targetPath;
    				move_uploaded_file($sourcePath,$targetPath) ; // Moving Uploaded file		
    				$img_path = $_FILES[$ij]['name'];

            		$picdata = array(
            		    'iui_u_id' => $uid,
            		    'iui_img' => $img_path,
            		    'iui_owner' => $oid
            		    );
            		$this->db->insert('i_u_images', $picdata);
			    }
			}
			echo $pid;
		}
	}

	
	public function edit_user($id) {
		$sess_data = $this->session->userdata();
		if(isset($sess_data['user_details'][0])) {
			$uid = $sess_data['user_details'][0]->iu_ref;
			$data['uid'] = $uid;
			
			$oid = $sess_data['user_details'][0]->iu_owner;
			$data['oid'] = $oid;

			$query = $this->db->query("SELECT * FROM i_users AS a LEFT JOIN i_u_access AS b ON a.iu_id=b.iua_u_id LEFT JOIN i_contacts AS c ON a.iu_ref=c.ic_id WHERE a.iu_type='distributor' AND a.iu_owner='$oid' AND a.iu_id='$id'");
			$result = $query->result();
			$data['user_info'] = $result;
			
			$query = $this->db->query("SELECT * FROM i_u_images WHERE iui_u_id='$id' AND iui_owner='$oid'");
			$result = $query->result();
			$data['user_img'] = $result;
			
			$data['id'] = $id;
			
			$ert['name'] = $sess_data['user_details'][0]->ic_name;			
			$ert['title'] = "Users and Access";
			$ert['search'] = "false";
			$ert['type'] = "distributors";
			
			$this->load->view('distributors/navbar', $ert);
			$this->load->view('distributors/account/user_add', $data);
		} else {
			redirect(base_url().'distributors/Account/login');
		}
	}

	public function update_user($id) {
		$sess_data = $this->session->userdata();
		if(isset($sess_data['user_details'][0])) {
			$uid = $sess_data['user_details'][0]->iu_ref;
			$oid = $sess_data['user_details'][0]->iu_owner;
			$dt = date('Y-m-d H:m:s');
			
			$query = $this->db->query("SELECT * FROM i_users WHERE iu_id='$id' AND iu_owner='$oid'");
			$result = $query->result();
			
			$cid = $result[0]->iu_ref;
			
			$data = array(
				'ic_name' => $this->input->post('name'),
				'ic_company' => $sess_data['user_details'][0]->ic_company,
				'ic_email' => $this->input->post('email'),
				'ic_phone' => $this->input->post('phone'),
				'ic_address' => $this->input->post('address'),
				'ic_owner' => $oid,
				'ic_section' => 'Distributor User'
				 );
            $this->db->where(array('ic_id' => $cid, 'ic_owner' => $oid ));				 
			$this->db->update('i_contacts', $data);

			$data = array(
				'iu_username' => $this->input->post('email'),
				'iu_type' => 'distributor',
				'iu_ref' => $cid,
				'iu_owner' => $oid,
				'iu_status' => 'password_u',
				'iu_subscription_start' => $sess_data['user_details'][0]->iu_subscription_start,
				'iu_subscription_end' => $sess_data['user_details'][0]->iu_subscription_end,
				'iu_created' => $dt,
				'iu_created_by' => $oid
			);
			
			$this->db->where(array('iu_id' => $id, 'iu_owner' => $oid));
			$this->db->update('i_users', $data);
			
			$data = array(
				'iua_u_products' => $this->input->post('per_product'),
				'iua_u_pricing' => $this->input->post('per_pricing'),
				'iua_u_dealers' => $this->input->post('per_dealers'),
				'iua_u_vendors' => $this->input->post('per_vendors'),
				'iua_u_orders' => $this->input->post('per_orders'),
				'iua_u_delivery' => $this->input->post('per_delivery'),
				'iua_u_inventory' => $this->input->post('per_inventory'),
				'iua_u_godown' => $this->input->post('per_godown'),
				'iua_u_purchase' => $this->input->post('per_purchase'),
				'iua_u_invoice' => $this->input->post('per_invoice'),
				'iua_u_credit_note' => $this->input->post('per_credit'),
				'iua_u_ledgers' => $this->input->post('per_ledgers'),
				'iua_u_expenses' => $this->input->post('per_expense'),
				'iua_u_payments' => $this->input->post('per_payments'),
				'iua_u_tax' => $this->input->post('per_tax'),
				'iua_u_users' => $this->input->post('per_users'),
				'iua_u_settings' => $this->input->post('per_settings'),
				 );
			$this->db->where(array('iua_u_id' => $id, 'iua_owner' => $oid));
			$this->db->update('i_u_access', $data);
			echo $id;
		} else {
			redirect(base_url().'distributors/Account/login');
		}
	}
	
	public function delete_user($id) {
	    $sess_data = $this->session->userdata();
		if(isset($sess_data['user_details'][0])) {
			$oid = $sess_data['user_details'][0]->iu_owner;
			$dt = date('Y-m-d H:m:s');
			
			$query = $this->db->query("SELECT * FROM i_users WHERE iu_id='$id' AND iu_owner='$oid'");
			$result = $query->result();
			
			$cid = $result[0]->iu_ref;
			
			$this->db->where(array('ic_id' => $cid, 'ic_owner' => $oid));
			$this->db->delete('i_contacts');
			
			$this->db->where(array('iu_id'=>$id, 'iu_owner' => $oid ));
			$this->db->delete('i_users');
			
			$this->db->where(array('iua_u_id' => $id, 'iua_owner' => $oid));
			$this->db->delete('i_u_access');
			
			redirect(base_url().'distributors/Account/users');
		} else {
			redirect(base_url().'distributors/Account/login');
		}
	}

    public function settings() {
        $sess_data = $this->session->userdata();
		if(isset($sess_data['user_details'][0])) {
			
			$ert['name'] = $sess_data['user_details'][0]->ic_name;			
			$ert['title'] = "Settings";
			$ert['search'] = "false";
			$ert['type'] = "distributors";
			
			$this->load->view('distributors/navbar', $ert);
			$this->load->view('distributors/account/settings');
		} else {
			redirect(base_url().'distributors/Account/login');
		}
    }
    

    public function tre() {
        $query = $this->db->select('*')->from('i_txns')->where(array('it_type' => 'Sale', 'it_date >' => '2018-04-04', 'it_date<' => '2018-04-20'));
        $q = $this->db->get();
        print_r($q->result());
    }
    
    public function delete_txns() {
        $sess_data = $this->session->userdata();
		if(isset($sess_data['user_details'][0])) {
		    
		    $oid = $sess_data['user_details'][0]->iu_owner;
		    if($this->input->post('ps') == $sess_data['user_details'][0]->iu_password) {
		        if($this->input->post('t') == "true") {
		            $from = $this->input->post('from');
		            $to = $this->input->post('to');
		            
		            $query = $this->db->query("SELECT * FROM i_txns WHERE it_owner='$oid' AND it_date BETWEEN '$from' AND '$to'");
		            $result = $query->result();
		            
		            for($i=0; $i< count($result);$i++) {
		                $tid = $result[$i]->it_id;
		                $this->db->where(array('itp_owner' => $oid, 'itd_t_id' => $tid));
		                $this->db->delete('i_txns_details');
		                
		                $this->db->where(array('itpt_owner' => $oid, 'itpt_txn_id' => $tid));
    		            $this->db->delete('i_txn_product_taxes');
    		            
    		            $this->db->where(array('ittd_owner' => $oid, 'ittd_txn_id' => $tid));
    		            $this->db->delete('i_txn_transport_details');
    		            
    		            $this->db->where(array('it_owner' => $oid, 'it_id' => $tid));
		                $this->db->delete('i_txns');
		            }
		            
		            $this->db->where("itn_date BETWEEN '$from' AND '$to'");
		            $this->db->where(array('itn_owner' => $oid));
		            $this->db->delete('i_txn_nums');
		            
		            $this->db->where(array('ith_owner' => $oid));
		            $this->db->delete('i_txns_history');
		            
		            $this->db->where("itp_date BETWEEN '$from' AND '$to'");
		            $this->db->where(array('itp_owner' => $oid));
		            $this->db->delete('i_txn_payments');
		            
		        }
		        
		        if($this->input->post('i') == "true") {
		            $this->db->where(array('ii_owner' => $oid));
		            $this->db->delete('i_inventory');
		        }
		        
		        if($this->input->post('g') == "true") {
		            $this->db->where(array('ig_owner' => $oid));
		            $this->db->delete('i_godowns');
		            
		            $this->db->where(array('igt_owner' => $oid));
		            $this->db->delete('i_g_transactions');
		        }
		        
		        echo "true";
		    } else {
		        echo "password";
		    }
		} else {
			redirect(base_url().'distributors/Account/login');
		}
    }

    public function reset_account_pass($sub=null) {
        $sess_data = $this->session->userdata();
        $vb = $this->input->post("uopass");
        if($sub!=null) {
            if($sess_data['sub'][0]->idu_password == $vb) {
                $data = array('idu_password' => $this->input->post('upass'));
        		$this->db->where(array('idu_id' => $sess_data['sub'][0]->idu_id, 'idu_dealer' => $sess_data['sub'][0]->idu_dealer, 'idu_owner' => $sess_data['sub'][0]->idu_owner ));
        		$this->db->update('i_d_users', $data);
        		echo "true";
            } else {
                echo "password";
            }
        } else {
            if($sess_data['user_details'][0]->iu_password == $vb) {
                $data = array('iu_password' => $this->input->post('upass'));
        		$this->db->where(array('iu_id' => $sess_data['user_details'][0]->iu_id, 'iu_type' => 'distributor' ));
        		$this->db->update('i_users', $data);
        		echo "true";
            } else {
                echo "password";
            }
        }
    }

    public function manage_financial($fyid=null) {
    	$sess_data = $this->session->userdata();
    	if(isset($sess_data['user_details'][0])) {
			$oid = $sess_data['user_details'][0]->iu_owner;
			$query = $this->db->query("SELECT * FROM i_financial_year WHERE ify_owner='$oid'");
			$data['fy'] = $query->result();

			if ($fyid!=null) {
				$data['fyid'] = $fyid;
				$query = $this->db->query("SELECT * FROM i_financial_year WHERE ify_owner='$oid' AND ify_id='$fyid'");
				$data['edit_fy'] = $query->result();
			}

			$ert['name'] = $sess_data['user_details'][0]->ic_name;			
			$ert['title'] = "Manage Financial";
			$ert['search'] = "false";
			$ert['type'] = "distributors";
			
			$this->load->view('distributors/navbar', $ert);
			$this->load->view('distributors/account/manage_financials', $data);
		} else {
			redirect(base_url().'distributors/Account/login');
		}
    }

    public function update_financial_year($fyid=null) {
    	$sess_data = $this->session->userdata();
		if(isset($sess_data['user_details'][0])) {
			$oid = $sess_data['user_details'][0]->iu_owner;
			if ($fyid == null) {
				$this->db->insert('i_financial_year', array('ify_year_code' => $this->input->post('cd'), 'ify_start_date' => $this->input->post('f'), 'ify_end_date' => $this->input->post('t'), 'ify_owner' => $oid, 'ify_active' => 'false'));	
			} else {
				$this->db->where(array('ify_id' => $fyid, 'ify_owner' => $oid));
				$this->db->update('i_financial_year', array('ify_year_code' => $this->input->post('cd'), 'ify_start_date' => $this->input->post('f'), 'ify_end_date' => $this->input->post('t')));
			}
			
		} else {
			redirect(base_url().'distributors/Account/login');
		}
    }

    public function choose_financial($fyid) {
    	$sess_data = $this->session->userdata();
		if(isset($sess_data['user_details'][0])) {
			$oid = $sess_data['user_details'][0]->iu_owner;


			$this->db->where(array('ify_owner' => $oid));
			$this->db->update('i_financial_year', array('ify_active' => 'false'));
			
			$this->db->where(array('ify_id' => $fyid, 'ify_owner' => $oid));
			$this->db->update('i_financial_year', array('ify_active' => 'true'));

			$query = $this->db->query("SELECT * FROM i_financial_year WHERE ify_owner='$oid' AND ify_id='$fyid'");
			$this->session->unset_userdata('fy');
			$data = array('fy' => $query->result());
    		$this->session->set_userdata($data);
			redirect(base_url().'distributors/Account/manage_financial');
		} else {
			redirect(base_url().'distributors/Account/login');
		}
    }


    
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct()	{
		parent:: __construct();
		$this->load->database();
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->library('email');
		$this->load->model('distributors/Transaction_Model','txn_model');
		$this->load->model('distributors/Products_Model','product_model');
		$this->load->dbforge();
	}
########## USER ACCOUNT, LOGIN, VERIFY AND LOGOUT ################
	public function index($oid) {
		$sess_data = $this->session->userdata();
		if(isset($sess_data['user_details'][0])) {
			$rid = $sess_data['user_details'][0]->iu_ref;
			$uid = $sess_data['user_details'][0]->iu_id;

            $oid = $sess_data['user_details'][0]->iu_owner;

            $query = $this->db->query("SELECT SUM(it_amount) AS amt FROM i_txns WHERE it_owner='$oid' AND it_type='Sale' AND it_c_id='$rid'");
			$data['sale_amount'] = $query->result();
			
			$query = $this->db->query("SELECT SUM(it_amount) AS amt FROM i_txns WHERE it_owner='$oid' AND it_type='Delivery' AND it_c_id='$rid'");
			$data['delivery_amount'] = $query->result();
			
			$data['pending'] = $this->txn_model->load_transactions_dealer($oid, 'pending', $rid);
			
// 			$data['products'] = $this->product_model->load_products_dealers($oid, $rid, null, 10);
// 			$data["product_list"] = $this->product_model->load_products($oid, null, 10);
			
			
			$data['oid'] = $oid;

			$ert['name'] = $sess_data['user_details'][0]->ic_name;
			
			$ert['title'] = "Home";
			$ert['search'] = "false";
			$ert['search_placeholder'] = "Search Products";
			$ert['type'] = "dealers";
		
			$this->load->view('dealers/navbar', $ert);
			$this->load->view('dealers/home/home', $data);
		} else {
			redirect(base_url().$this->config->item('dealer_login_red'));
		}
	}
}